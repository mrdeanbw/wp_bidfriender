<?php
// this defines the custom post type name

global $custom_post_project_type_name;
$custom_post_project_type_name = 'project';

 ?>
